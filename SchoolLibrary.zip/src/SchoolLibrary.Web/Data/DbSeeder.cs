using SchoolLibrary.Web.Models;
using SchoolLibrary.Web.Services;

namespace SchoolLibrary.Web.Data;

/// <summary>Демонстрационни данни (само при празна база). ISBN номерата са примерни.</summary>
public static class DbSeeder
{
    public static void Seed(LibraryDbContext db)
    {
        db.Database.EnsureCreated();
        if (db.Books.Any()) return;

        var books = new[]
        {
            new Book { Title = "Под игото", Author = "Иван Вазов", Isbn = "9789540000015", Genre = "Роман", Copies = 3 },
            new Book { Title = "Железният светилник", Author = "Димитър Талев", Isbn = "9789540000022", Genre = "Роман", Copies = 2 },
            new Book { Title = "Тютюн", Author = "Димитър Димов", Isbn = "9789540000039", Genre = "Роман", Copies = 2 },
            new Book { Title = "Бай Ганьо", Author = "Алеко Константинов", Isbn = "9789540000046", Genre = "Сатира", Copies = 2 },
            new Book { Title = "Градинарят и смъртта", Author = "Георги Господинов", Isbn = "9789540000053", Genre = "Проза", Copies = 1 },
            new Book { Title = "Хайдути", Author = "Иван Вазов", Isbn = "9789540000060", Genre = "Поезия", Copies = 1 },
            new Book { Title = "Некрополис", Author = "Иван Вазов", Isbn = "9789540000077", Genre = "Поезия", Copies = 1 },
            new Book { Title = "Българско ястие", Author = "Йордан Йовков", Isbn = "9789540000084", Genre = "Разкази", Copies = 2 },
            new Book { Title = "Старопланински легенди", Author = "Йордан Йовков", Isbn = "9789540000091", Genre = "Разкази", Copies = 2 },
            new Book { Title = "Приказки за деца", Author = "Ран Босилек", Isbn = "9789540000107", Genre = "Детска литература", Copies = 4 },
        };
        db.Books.AddRange(books);

        var readers = new[]
        {
            new Reader { FullName = "Мария Георгиева", Type = ReaderType.Student, ClassName = "8Б" },
            new Reader { FullName = "Петър Иванов", Type = ReaderType.Student, ClassName = "10А" },
            new Reader { FullName = "Елена Димитрова", Type = ReaderType.Teacher },
        };
        db.Readers.AddRange(readers);
        db.SaveChanges();

        var today = DateTime.Today;
        db.Loans.AddRange(
            new Loan { BookId = books[0].Id, ReaderId = readers[0].Id, LoanedOn = today.AddDays(-20), DueOn = LibraryRules.DueDate(today.AddDays(-20)) },
            new Loan { BookId = books[2].Id, ReaderId = readers[1].Id, LoanedOn = today.AddDays(-3), DueOn = LibraryRules.DueDate(today.AddDays(-3)) },
            new Loan { BookId = books[3].Id, ReaderId = readers[2].Id, LoanedOn = today.AddDays(-40), DueOn = LibraryRules.DueDate(today.AddDays(-40)),
                       ReturnedOn = today.AddDays(-20), FineStotinki = LibraryRules.Fine(LibraryRules.DueDate(today.AddDays(-40)), today.AddDays(-20)) });
        db.SaveChanges();
    }
}
