using Microsoft.EntityFrameworkCore;
using SchoolLibrary.Web.Models;

namespace SchoolLibrary.Web.Data;

public class LibraryDbContext : DbContext
{
    public LibraryDbContext(DbContextOptions<LibraryDbContext> options) : base(options) { }

    public DbSet<Book> Books => Set<Book>();
    public DbSet<Reader> Readers => Set<Reader>();
    public DbSet<Loan> Loans => Set<Loan>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Book>().HasIndex(x => x.Isbn).IsUnique();

        // BR-06: история на заеманията - книга/читател със заемания не се трие
        b.Entity<Loan>().HasOne(l => l.Book).WithMany(x => x.Loans)
            .HasForeignKey(l => l.BookId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Loan>().HasOne(l => l.Reader).WithMany(r => r.Loans)
            .HasForeignKey(l => l.ReaderId).OnDelete(DeleteBehavior.Restrict);
    }
}
