namespace SchoolLibrary.Web.Services;

/// <summary>Бизнес правилата на библиотеката на едно място (BR-xx).</summary>
public static class LibraryRules
{
    public const int LoanDays = 14;               // BR-01: срок за връщане
    public const int MaxActiveLoans = 3;          // BR-02: най-много книги наведнъж (и за учители)
    public const int FinePerDayStotinki = 20;     // BR-05: 0,20 лв. на ден
    public const int MaxFineStotinki = 1000;      // BR-05: таван 10 лв.

    public static DateTime DueDate(DateTime loanedOn) => loanedOn.Date.AddDays(LoanDays);

    /// <summary>Дни просрочие към дадена дата (0, ако не е закъсняла).</summary>
    public static int DaysOverdue(DateTime dueOn, DateTime asOf) =>
        Math.Max(0, (asOf.Date - dueOn.Date).Days);

    /// <summary>Глоба в стотинки: 20 ст. на ден, най-много 10 лв.</summary>
    public static int Fine(DateTime dueOn, DateTime asOf) =>
        Math.Min(DaysOverdue(dueOn, asOf) * FinePerDayStotinki, MaxFineStotinki);

    public static string FormatMoney(int stotinki) => $"{stotinki / 100m:0.00} лв.";
}
