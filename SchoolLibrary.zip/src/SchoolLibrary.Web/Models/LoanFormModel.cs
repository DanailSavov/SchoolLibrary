using System.ComponentModel.DataAnnotations;

namespace SchoolLibrary.Web.Models;

public class LoanFormModel
{
    [Range(1, int.MaxValue, ErrorMessage = "Изберете книга.")]
    [Display(Name = "Книга")]
    public int BookId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Изберете читател.")]
    [Display(Name = "Читател")]
    public int ReaderId { get; set; }
}
