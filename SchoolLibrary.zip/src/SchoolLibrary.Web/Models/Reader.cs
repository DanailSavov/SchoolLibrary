using System.ComponentModel.DataAnnotations;

namespace SchoolLibrary.Web.Models;

public enum ReaderType
{
    [Display(Name = "Ученик")] Student = 0,
    [Display(Name = "Учител")] Teacher = 1
}

public class Reader : IValidatableObject
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Името е задължително.")]
    [StringLength(100, ErrorMessage = "Името може да е до {1} символа.")]
    [Display(Name = "Име и фамилия")]
    public string FullName { get; set; } = string.Empty;

    [Display(Name = "Вид читател")]
    public ReaderType Type { get; set; }

    [StringLength(20, ErrorMessage = "Класът може да е до {1} символа.")]
    [Display(Name = "Клас")]
    public string? ClassName { get; set; }

    [StringLength(100, ErrorMessage = "Имейлът може да е до {1} символа.")]
    [EmailAddress(ErrorMessage = "Невалиден имейл адрес.")]
    [Display(Name = "Имейл (по желание)")]
    public string? Email { get; set; }

    public List<Loan> Loans { get; set; } = new();

    public int ActiveLoans => Loans.Count(l => l.ReturnedOn == null);

    public IEnumerable<ValidationResult> Validate(ValidationContext ctx)
    {
        if (!Enum.IsDefined(typeof(ReaderType), Type))
            yield return new ValidationResult("Невалиден вид читател.", new[] { nameof(Type) });
        if (Type == ReaderType.Student && string.IsNullOrWhiteSpace(ClassName))
            yield return new ValidationResult("Класът е задължителен за ученик.", new[] { nameof(ClassName) });
    }
}
