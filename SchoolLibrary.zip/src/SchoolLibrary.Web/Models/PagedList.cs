namespace SchoolLibrary.Web.Models;

public interface IPagedResult
{
    int Page { get; }
    int PageSize { get; }
    int TotalCount { get; }
    int TotalPages { get; }
}

public class PagedList<T> : IPagedResult
{
    public static readonly int[] AllowedPageSizes = { 10, 25, 50 };
    public const int DefaultPageSize = 10;

    public List<T> Items { get; init; } = new();
    public int Page { get; init; }
    public int PageSize { get; init; }
    public int TotalCount { get; init; }
    public int TotalPages => Math.Max(1, (int)Math.Ceiling(TotalCount / (double)PageSize));

    public static PagedList<T> Create(IEnumerable<T> source, int page, int pageSize)
    {
        if (!AllowedPageSizes.Contains(pageSize)) pageSize = DefaultPageSize;
        var all = source.ToList();
        var pages = Math.Max(1, (int)Math.Ceiling(all.Count / (double)pageSize));
        page = Math.Clamp(page, 1, pages);
        return new PagedList<T>
        {
            Items = all.Skip((page - 1) * pageSize).Take(pageSize).ToList(),
            Page = page, PageSize = pageSize, TotalCount = all.Count
        };
    }
}
