using SchoolLibrary.Web.Services;

namespace SchoolLibrary.Web.Models;

public class Loan
{
    public int Id { get; set; }

    public int BookId { get; set; }
    public Book Book { get; set; } = null!;

    public int ReaderId { get; set; }
    public Reader Reader { get; set; } = null!;

    public DateTime LoanedOn { get; set; }
    public DateTime DueOn { get; set; }
    public DateTime? ReturnedOn { get; set; }

    /// <summary>Глоба, записана при връщане, в стотинки.</summary>
    public int FineStotinki { get; set; }

    public bool IsOverdue(DateTime today) => ReturnedOn == null && today.Date > DueOn.Date;
    public int DaysOverdue(DateTime today) => LibraryRules.DaysOverdue(DueOn, ReturnedOn ?? today);
    public int CurrentFine(DateTime today) => ReturnedOn != null ? FineStotinki : LibraryRules.Fine(DueOn, today);
}
