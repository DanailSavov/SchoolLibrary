using System.ComponentModel.DataAnnotations;

namespace SchoolLibrary.Web.Models;

public class Book
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Заглавието е задължително.")]
    [StringLength(200, ErrorMessage = "Заглавието може да е до {1} символа.")]
    [Display(Name = "Заглавие")]
    public string Title { get; set; } = string.Empty;

    [Required(ErrorMessage = "Авторът е задължителен.")]
    [StringLength(150, ErrorMessage = "Авторът може да е до {1} символа.")]
    [Display(Name = "Автор")]
    public string Author { get; set; } = string.Empty;

    [Required(ErrorMessage = "ISBN е задължителен.")]
    [StringLength(20, ErrorMessage = "ISBN може да е до {1} символа.")]
    [Isbn]
    [Display(Name = "ISBN")]
    public string Isbn { get; set; } = string.Empty;

    [Required(ErrorMessage = "Жанрът е задължителен.")]
    [StringLength(50, ErrorMessage = "Жанрът може да е до {1} символа.")]
    [Display(Name = "Жанр")]
    public string Genre { get; set; } = string.Empty;

    [Range(1, 100, ErrorMessage = "Екземплярите трябва да са между {1} и {2}.")]
    [Display(Name = "Брой екземпляри")]
    public int Copies { get; set; } = 1;

    public List<Loan> Loans { get; set; } = new();

    public int ActiveLoans => Loans.Count(l => l.ReturnedOn == null);
    public int Available => Copies - ActiveLoans;
}

/// <summary>Валидира ISBN-10 / ISBN-13 (с контролна цифра). Тирета и интервали се допускат.</summary>
[AttributeUsage(AttributeTargets.Property)]
public class IsbnAttribute : ValidationAttribute
{
    public IsbnAttribute() : base("Невалиден ISBN (10 или 13 цифри с верна контролна цифра).") { }

    public static string Normalize(string s) =>
        new string(s.Where(c => char.IsDigit(c) || c == 'X' || c == 'x').ToArray()).ToUpperInvariant();

    public static bool IsValidIsbn(string normalized)
    {
        if (normalized.Length == 13 && normalized.All(char.IsDigit))
        {
            var sum = 0;
            for (var i = 0; i < 12; i++) sum += (normalized[i] - '0') * (i % 2 == 0 ? 1 : 3);
            return (10 - sum % 10) % 10 == normalized[12] - '0';
        }
        if (normalized.Length == 10 && normalized[..9].All(char.IsDigit))
        {
            var sum = 0;
            for (var i = 0; i < 9; i++) sum += (normalized[i] - '0') * (10 - i);
            sum += normalized[9] == 'X' ? 10 : char.IsDigit(normalized[9]) ? normalized[9] - '0' : -100;
            return sum % 11 == 0;
        }
        return false;
    }

    public override bool IsValid(object? value) =>
        value is string s && !string.IsNullOrWhiteSpace(s) && s.All(c => char.IsLetterOrDigit(c) || c == '-' || c == ' ')
        && IsValidIsbn(Normalize(s));
}
