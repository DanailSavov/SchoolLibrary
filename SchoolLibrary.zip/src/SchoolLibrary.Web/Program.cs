using Microsoft.EntityFrameworkCore;
using SchoolLibrary.Web.Data;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

var cs = builder.Configuration.GetConnectionString("Default") ?? "Data Source=App_Data/library.db";
Directory.CreateDirectory(Path.Combine(builder.Environment.ContentRootPath, "App_Data"));
builder.Services.AddDbContext<LibraryDbContext>(o => o.UseSqlite(cs));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
    DbSeeder.Seed(scope.ServiceProvider.GetRequiredService<LibraryDbContext>());

if (!app.Environment.IsDevelopment()) app.UseExceptionHandler("/Home/Error");
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
app.Run();
