using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SchoolLibrary.Web.Data;
using SchoolLibrary.Web.Models;

namespace SchoolLibrary.Web.Controllers;

public class BooksController : Controller
{
    private readonly LibraryDbContext _db;
    public BooksController(LibraryDbContext db) => _db = db;

    // FR-01, FR-02, FR-03: каталог, търсене по заглавие/автор/ISBN, филтър по жанр
    public async Task<IActionResult> Index(string? search, string? genre, int page = 1, int pageSize = PagedList<Book>.DefaultPageSize)
    {
        var all = await _db.Books.Include(b => b.Loans).AsNoTracking().ToListAsync();
        ViewBag.Genres = new SelectList(all.Select(b => b.Genre).Distinct().OrderBy(g => g), genre);

        IEnumerable<Book> q = all;
        search = search?.Trim();
        if (!string.IsNullOrEmpty(search))
        {
            // Търсенето е в паметта, защото SQLite не прави регистронезависимо сравнение за кирилица
            var digits = IsbnAttribute.Normalize(search);
            q = q.Where(b => b.Title.Contains(search, StringComparison.OrdinalIgnoreCase)
                          || b.Author.Contains(search, StringComparison.OrdinalIgnoreCase)
                          || (digits.Length >= 3 && b.Isbn.Contains(digits, StringComparison.OrdinalIgnoreCase)));
        }
        if (!string.IsNullOrEmpty(genre)) q = q.Where(b => b.Genre == genre);

        ViewBag.Search = search;
        return View(PagedList<Book>.Create(q.OrderBy(b => b.Title), page, pageSize));
    }

    public async Task<IActionResult> Details(int id)
    {
        var book = await _db.Books.Include(b => b.Loans).ThenInclude(l => l.Reader)
            .AsNoTracking().FirstOrDefaultAsync(b => b.Id == id);
        return book == null ? NotFound() : View(book);
    }

    [HttpGet] public IActionResult Create() => View(new Book());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Title,Author,Isbn,Genre,Copies")] Book book)
    {
        Trim(book);
        await CheckIsbn(book);
        if (!ModelState.IsValid) return View(book);
        _db.Books.Add(book);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Книгата е добавена.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var book = await _db.Books.AsNoTracking().FirstOrDefaultAsync(b => b.Id == id);
        return book == null ? NotFound() : View(book);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Author,Isbn,Genre,Copies")] Book input)
    {
        if (id != input.Id) return BadRequest();
        var book = await _db.Books.Include(b => b.Loans).FirstOrDefaultAsync(b => b.Id == id);
        if (book == null) return NotFound();

        Trim(input);
        await CheckIsbn(input);
        if (input.Copies < book.ActiveLoans)
            ModelState.AddModelError(nameof(Book.Copies), $"В момента са заети {book.ActiveLoans} екземпляра – не може да са по-малко.");
        if (!ModelState.IsValid) return View(input);

        book.Title = input.Title; book.Author = input.Author; book.Isbn = input.Isbn;
        book.Genre = input.Genre; book.Copies = input.Copies;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Промените са запазени.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var book = await _db.Books.Include(b => b.Loans).AsNoTracking().FirstOrDefaultAsync(b => b.Id == id);
        return book == null ? NotFound() : View(book);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var book = await _db.Books.Include(b => b.Loans).FirstOrDefaultAsync(b => b.Id == id);
        if (book == null) return NotFound();
        if (book.Loans.Any()) // BR-06
        {
            TempData["Error"] = "Книга, която е била заемана, не може да се изтрие – историята се пази.";
            return RedirectToAction(nameof(Details), new { id });
        }
        _db.Books.Remove(book);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Книгата е изтрита.";
        return RedirectToAction(nameof(Index));
    }

    private static void Trim(Book b)
    {
        b.Title = b.Title?.Trim() ?? ""; b.Author = b.Author?.Trim() ?? "";
        b.Genre = b.Genre?.Trim() ?? "";
    }

    /// <summary>Нормализира ISBN (само цифри/X) и проверява за дубликат.</summary>
    private async Task CheckIsbn(Book b)
    {
        if (!ModelState.IsValid && ModelState[nameof(Book.Isbn)]?.Errors.Count > 0) return;
        b.Isbn = IsbnAttribute.Normalize(b.Isbn ?? "");
        if (await _db.Books.AnyAsync(x => x.Isbn == b.Isbn && x.Id != b.Id))
            ModelState.AddModelError(nameof(Book.Isbn), "Книга с този ISBN вече съществува.");
    }
}
