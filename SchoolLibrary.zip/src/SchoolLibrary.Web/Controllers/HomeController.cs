using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolLibrary.Web.Data;
using SchoolLibrary.Web.Models;

namespace SchoolLibrary.Web.Controllers;

public class HomeController : Controller
{
    private readonly LibraryDbContext _db;
    public HomeController(LibraryDbContext db) => _db = db;

    // FR-10/11: просрочени книги и табло
    public async Task<IActionResult> Index()
    {
        var today = DateTime.Today;
        var active = await _db.Loans.Include(l => l.Book).Include(l => l.Reader)
            .AsNoTracking().Where(l => l.ReturnedOn == null).ToListAsync();
        ViewBag.Today = today;
        ViewBag.BookCount = await _db.Books.CountAsync();
        ViewBag.ReaderCount = await _db.Readers.CountAsync();
        ViewBag.ActiveCount = active.Count;
        var overdue = active.Where(l => l.IsOverdue(today)).OrderBy(l => l.DueOn).ToList();
        return View(overdue);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() =>
        View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}
