using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SchoolLibrary.Web.Data;
using SchoolLibrary.Web.Models;
using SchoolLibrary.Web.Services;

namespace SchoolLibrary.Web.Controllers;

public class LoansController : Controller
{
    private readonly LibraryDbContext _db;
    public LoansController(LibraryDbContext db) => _db = db;

    // status: active | overdue | returned | all
    public async Task<IActionResult> Index(string? status, string? search, int page = 1, int pageSize = PagedList<Loan>.DefaultPageSize)
    {
        status = string.IsNullOrEmpty(status) ? "active" : status;
        var today = DateTime.Today;
        IEnumerable<Loan> q = await _db.Loans.Include(l => l.Book).Include(l => l.Reader).AsNoTracking().ToListAsync();

        q = status switch
        {
            "active" => q.Where(l => l.ReturnedOn == null),
            "overdue" => q.Where(l => l.IsOverdue(today)),
            "returned" => q.Where(l => l.ReturnedOn != null),
            _ => q
        };
        search = search?.Trim();
        if (!string.IsNullOrEmpty(search))
            q = q.Where(l => l.Reader.FullName.Contains(search, StringComparison.OrdinalIgnoreCase)
                          || l.Book.Title.Contains(search, StringComparison.OrdinalIgnoreCase));

        ViewBag.Status = status;
        ViewBag.Search = search;
        return View(PagedList<Loan>.Create(q.OrderBy(l => l.ReturnedOn != null).ThenBy(l => l.DueOn).ThenBy(l => l.Id), page, pageSize));
    }

    // FR-08: заемане
    [HttpGet]
    public async Task<IActionResult> Create(int? bookId, int? readerId)
    {
        await FillLists();
        return View(new LoanFormModel { BookId = bookId ?? 0, ReaderId = readerId ?? 0 });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(LoanFormModel vm)
    {
        var book = await _db.Books.Include(b => b.Loans).FirstOrDefaultAsync(b => b.Id == vm.BookId);
        var reader = await _db.Readers.Include(r => r.Loans).FirstOrDefaultAsync(r => r.Id == vm.ReaderId);

        if (book == null) ModelState.AddModelError(nameof(vm.BookId), "Изберете книга.");
        else if (book.Available <= 0)
            ModelState.AddModelError(nameof(vm.BookId), "Няма свободен екземпляр от тази книга.");

        if (reader == null) ModelState.AddModelError(nameof(vm.ReaderId), "Изберете читател.");
        else
        {
            if (reader.ActiveLoans >= LibraryRules.MaxActiveLoans) // BR-02
                ModelState.AddModelError(nameof(vm.ReaderId),
                    $"Читателят вече има {LibraryRules.MaxActiveLoans} заети книги (максимум).");
            if (book != null && reader.Loans.Any(l => l.BookId == book.Id && l.ReturnedOn == null))
                ModelState.AddModelError(nameof(vm.BookId), "Читателят вече държи тази книга.");
        }
        if (!ModelState.IsValid) { await FillLists(); return View(vm); }

        var today = DateTime.Today;
        _db.Loans.Add(new Loan
        {
            BookId = book!.Id, ReaderId = reader!.Id,
            LoanedOn = today, DueOn = LibraryRules.DueDate(today) // BR-01
        });
        await _db.SaveChangesAsync();
        TempData["Success"] = $"„{book.Title}“ е заета от {reader.FullName} до {LibraryRules.DueDate(today):dd.MM.yyyy}.";
        return RedirectToAction(nameof(Index));
    }

    // FR-09: връщане + глоба
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Return(int id, string? returnTo)
    {
        var loan = await _db.Loans.Include(l => l.Book).Include(l => l.Reader).FirstOrDefaultAsync(l => l.Id == id);
        if (loan == null) return NotFound();
        if (loan.ReturnedOn != null)
        {
            TempData["Error"] = "Книгата вече е върната.";
            return RedirectToAction(nameof(Index));
        }
        var today = DateTime.Today;
        loan.ReturnedOn = today;
        loan.FineStotinki = LibraryRules.Fine(loan.DueOn, today);
        await _db.SaveChangesAsync();

        var msg = $"„{loan.Book.Title}“ е върната от {loan.Reader.FullName}.";
        if (loan.FineStotinki > 0)
            TempData["Fine"] = $"{msg} Закъснение: {loan.DaysOverdue(today)} дни. Глоба за събиране: {LibraryRules.FormatMoney(loan.FineStotinki)}.";
        else
            TempData["Success"] = msg + " Без глоба.";
        return RedirectToAction(nameof(Index));
    }

    private async Task FillLists()
    {
        var books = (await _db.Books.Include(b => b.Loans).AsNoTracking().ToListAsync())
            .Where(b => b.Available > 0).OrderBy(b => b.Title)
            .Select(b => new { b.Id, Name = $"{b.Title} – {b.Author} (свободни: {b.Available})" });
        ViewBag.Books = new SelectList(books, "Id", "Name");
        var readers = (await _db.Readers.AsNoTracking().OrderBy(r => r.FullName).ToListAsync())
            .Select(r => new { r.Id, Name = r.Type == ReaderType.Student ? $"{r.FullName} ({r.ClassName})" : $"{r.FullName} (учител)" });
        ViewBag.Readers = new SelectList(readers, "Id", "Name");
    }
}
