using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolLibrary.Web.Data;
using SchoolLibrary.Web.Models;

namespace SchoolLibrary.Web.Controllers;

public class ReadersController : Controller
{
    private readonly LibraryDbContext _db;
    public ReadersController(LibraryDbContext db) => _db = db;

    public async Task<IActionResult> Index(string? search, int page = 1, int pageSize = PagedList<Reader>.DefaultPageSize)
    {
        IEnumerable<Reader> q = await _db.Readers.Include(r => r.Loans).AsNoTracking().ToListAsync();
        search = search?.Trim();
        if (!string.IsNullOrEmpty(search))
            q = q.Where(r => r.FullName.Contains(search, StringComparison.OrdinalIgnoreCase)
                          || (r.ClassName != null && r.ClassName.Contains(search, StringComparison.OrdinalIgnoreCase)));
        ViewBag.Search = search;
        return View(PagedList<Reader>.Create(q.OrderBy(r => r.FullName), page, pageSize));
    }

    public async Task<IActionResult> Details(int id)
    {
        var reader = await _db.Readers.Include(r => r.Loans).ThenInclude(l => l.Book)
            .AsNoTracking().FirstOrDefaultAsync(r => r.Id == id);
        return reader == null ? NotFound() : View(reader);
    }

    [HttpGet] public IActionResult Create() => View(new Reader());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("FullName,Type,ClassName,Email")] Reader reader)
    {
        Normalize(reader);
        if (!ModelState.IsValid) return View(reader);
        _db.Readers.Add(reader);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Читателят е добавен.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var r = await _db.Readers.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return r == null ? NotFound() : View(r);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,FullName,Type,ClassName,Email")] Reader input)
    {
        if (id != input.Id) return BadRequest();
        var reader = await _db.Readers.FindAsync(id);
        if (reader == null) return NotFound();
        Normalize(input);
        if (!ModelState.IsValid) return View(input);
        reader.FullName = input.FullName; reader.Type = input.Type;
        reader.ClassName = input.ClassName; reader.Email = input.Email;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Промените са запазени.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var r = await _db.Readers.Include(x => x.Loans).AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);
        return r == null ? NotFound() : View(r);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var r = await _db.Readers.Include(x => x.Loans).FirstOrDefaultAsync(x => x.Id == id);
        if (r == null) return NotFound();
        if (r.Loans.Any())
        {
            TempData["Error"] = "Читател със заемания не може да се изтрие – историята се пази.";
            return RedirectToAction(nameof(Details), new { id });
        }
        _db.Readers.Remove(r);
        await _db.SaveChangesAsync();
        TempData["Success"] = "Читателят е изтрит.";
        return RedirectToAction(nameof(Index));
    }

    private static void Normalize(Reader r)
    {
        r.FullName = r.FullName?.Trim() ?? "";
        r.ClassName = string.IsNullOrWhiteSpace(r.ClassName) ? null : r.ClassName.Trim();
        r.Email = string.IsNullOrWhiteSpace(r.Email) ? null : r.Email.Trim();
        if (r.Type == ReaderType.Teacher) r.ClassName = null;
    }
}
